<?php
/**
 * PHP Antivirus
 * @author Tim
 */
class Antivirus extends Module {
    
    public function __construct(){
		parent::__construct();
        $this->configFile = ROOT_DIR_SERVICE."antivirus.dat";
		$this->dataOfFileAlert = ROOT_DIR_SERVICE."dataOfFileAlerts.dat";
		$this->currentConfig = $this->GetConfig(true);
		
		if($this->settings->antivirus_enabled){
            $this->enable = true;
            $this->SendAlerts($this->currentConfig);
        } 
    }
    
    public function Run($force_start = false){
        if(!$this->enable)
            return;
       $command = false;
       if($force_start)
			if(!$this->Check())
				$command ="force_start";
			else
				return;	
       $conveyer = new Conveyers("antivirus", $command);
       $conveyer->Run(SITE_URL."/cron/conveyers/antivirus/minor.php", (!$force_start)?array($this, "ExecAlertHandlers"):false);
    }
    
    public function Stop(){
        $conveyer = new Conveyers("antivirus", "console");
        $conveyer->ExecCommand("end");
    }
    
    public function ExecAlertHandlers(){
        foreach($this->alertHandlers as $val){
            $this->$val();
        }
    }
    
    public function InternalChecking(){
        if($this->enable and !$this->Check)
        {
            $this->AddAlerts("Сбой в работе антивируса.");
            $this->errorHandlerObject->Push(ERROR_HANDLER_WARNING, 1, "Сбой в работе антивируса");
        }
    }
    
    public function ShowAlerts($config = false){
        if(!$config)
             $config = $this->currentConfig;
		$result = "";
		
		if($config['alerts']){
			$this->tpl->add_var("alerts", $config['alerts']);
			$result =  $this->tpl->fetch("antivirus_show_alerts");
		}
        return $result;
    }
    
    public function AddAlert($string, $time, $file = ""){
        if(!$string)
            return;  
       fclose(fopen($this->configFile, "a+"));
       $fp = fopen($this->configFile, "r+");
	   if(!$fp){
			$fileLine = $this->FileLineCalc();
			$this->errorHandlerObject->Push(ERROR_HANDLER_ERROR, 8, "Ошибка открытия файла", $fileLine[0], $fileLine[1]);
	   }
       flock($fp, LOCK_EX);
       $data = "";
       while(!feof($fp))
            $data .= fread($fp, 100000);
       @$data = unserialize($data);
       if(!$data){
           flock($fp, LOCK_UN); 
           $data = $this->GetConfig();
           flock($fp, LOCK_EX);
       }
       
       $data['alerts'][] = array("string" => $string, "time" => $time, "file" => $file);
       
       ftruncate($fp, 0);
       fseek($fp, 0);
       fwrite($fp, serialize($data));
       
       flock($fp, LOCK_UN); 
       fclose($fp);
    }
  
	public function GetAlerts($newOnly = false)
	{
		$alerts = $this->antivirus->GetConfig($newOnly);
		$alerts = $alerts['alerts'];
		return $alerts;
	}
	
    public function SendAlerts($config = false, $force = false){
        if(!$config)
             $config = $this->GetConfig(true);
		
        if(((time() - $config['config']['last_sending_time']) < $this->sendingInterval) and !$force)
            return;
        
        $alerts = $config['alerts'];
        if($alerts){
			$string = "";
            $count = 0;
			$fileCount = 0;
			
			$files = array();
			
            foreach($alerts as $val){
				 $count++;
                 $string .= ("[".date("d-m-Y H:i:s", $val['time'])."]".(($val['file'] and file_exists($val['file']))?"[file_".$fileCount."]":"").$val['string']."**del**");
				 if($val['file'] and file_exists($val['file']))
					$files['file_'.($fileCount++)] = $val['file'];		
			}
			SendInfoToDev("antivirus", array("lastAlerts" => $string), $files);
                                           
             if(!$this->errorHandlerObject->GetNumErrors()){
				$config = $this->GetConfig();
				$config['config']['last_old_pos'] += $count;
				$config['config']['last_sending_time'] = time(); 
				
				if(filesize($this->configFile) > $config['config']['max_config_size'])
					$config = serialize(array("config" => $config['config'], "alerts" => array(), "notices" => array()));
				
                 $fp = fopen($this->configFile, "r+");
				 if(!$fp){
					$fileLine = $this->FileLineCalc();
					$this->errorHandlerObject->Push(ERROR_HANDLER_ERROR, 8, "Ошибка открытия файла", $fileLine[0], $fileLine[1]);
				 }
                 flock($fp, LOCK_EX);
                 ftruncate($fp, 0);
                 fseek($fp, 0);
                 fwrite($fp, serialize($config));
                 flock($fp, LOCK_UN);
                 fclose($fp);
            }
        }
    }
    
    public function GetNumNotices($new = false){
		$count = 0;
		if($new){
			$count = $this->GetConfig();
			$count = count($count['notices']);
		}
		else
			$count = count($this->currentConfig['notices']);
        return $count;
    }
    
    public function  GetNotices($new = false){
		if(!$new)
			$notices = $this->currentConfig['notices'];
		else{
			$notices = $this->GetConfig();
			$notices = $notices['notices'];
		}
		return $notices;
    }
    
    public function AddNotice($string, $action, $add = false){
       if(!$string or !$action)
            return;  
	   $this->DeleteNotice($action);
       fclose(fopen($this->configFile, "a+"));
       $fp = fopen($this->configFile, "r+");
	   if(!$fp){
			$fileLine = $this->FileLineCalc();
			$this->errorHandlerObject->Push(ERROR_HANDLER_ERROR, 8, "Ошибка открытия файла", $fileLine[0], $fileLine[1]);
		}
       flock($fp, LOCK_EX);
       $data = "";
       while(!feof($fp))
            $data .= fread($fp, 100000);
       @$data = unserialize($data);
       if(!$data){
           flock($fp, LOCK_UN); 
           $data = $this->GetConfig();
           flock($fp, LOCK_EX);
       }
       
       $data['notices'][] = array("string" => $string, "action" => $action, "add" => $add);
       
       ftruncate($fp, 0);
       fseek($fp, 0);
       fwrite($fp, serialize($data));
       
       flock($fp, LOCK_UN); 
       fclose($fp);
    }
	
	public function DeleteNotice($action){
		if(!$action)
			return;
	   fclose(fopen($this->configFile, "a+"));
       $fp = fopen($this->configFile, "r+");
	   if(!$fp){
			$fileLine = $this->FileLineCalc();
			$this->errorHandlerObject->Push(ERROR_HANDLER_ERROR, 8, "Ошибка открытия файла", $fileLine[0], $fileLine[1]);
	   }
       flock($fp, LOCK_EX);
       $data = "";
       while(!feof($fp))
            $data .= fread($fp, 100000);
       @$data = unserialize($data);
       if(!$data){
           flock($fp, LOCK_UN); 
           $data = $this->GetConfig();
           flock($fp, LOCK_EX);
       }
	   $notices = $data['notices'];
	   $newArr = array();
	   foreach($notices as $notice)
			if($notice['action'] != $action)
				$newArr[] = $notice;
	   $data['notices'] = $newArr;
		ftruncate($fp, 0);
		fseek($fp, 0);
		fwrite($fp, serialize($data));
       
		flock($fp, LOCK_UN); 
		fclose($fp);
	}
    
    private function Check(){
        $conveyer = new Conveyers("antivirus", "console");
        return $conveyer->ExecCommand("check");
    }
    
    private function GetConfig($newOnly = false){
        fclose(fopen($this->configFile, "a+"));
        $fp = fopen($this->configFile, "r+");
		if(!$fp){
			$fileLine = $this->FileLineCalc();
			$this->errorHandlerObject->Push(ERROR_HANDLER_ERROR, 8, "Ошибка открытия файла", $fileLine[0], $fileLine[1]);
		}
        flock($fp, LOCK_SH);
        $data = "";
        while(!feof($fp))
            $data .= fread($fp, 100000);
        flock($fp, LOCK_UN);
        @$data = unserialize($data);
        if(!$data)
        {
            $data = array(
                "config" => array("last_old_pos" => 0, "last_sending_time" => time() - $this->sendingInterval - 1, "max_config_size" => 1024*1024),
                "alerts" => array(),
				"notices" => array()
            );
            flock($fp, LOCK_EX);
            ftruncate($fp, 0);
            fseek($fp, 0);
            fwrite($fp, serialize($data));
            flock($fp, LOCK_UN);
        }
        fclose($fp);
            
        $alerts = array();
			foreach($data['alerts'] as $key => $val){
				if($newOnly){
					if($key >= $data['config']['last_old_pos'])
						$alerts[] = $val;
				}
				else{
					$alerts[] = $val;
				}
			}
        
        return array("config" => $data['config'], "alerts" => $alerts, "notices" => $data['notices']);
    }
    
    private function IsEnable(){
        return $this->enable;
    }
    
	//alertHandlers
	//fileAlert
	public function fileAlert($addAllowed = array()){
		$interval = $this->fileAlertInterval;
		if(!$addAllowed and ((time() - $this->settings->last_file_alert_scan) <= ($interval)))
			return;
		
		//scan
		$data = $this->fileAlertScan(strtr($_SERVER['DOCUMENT_ROOT'], "\\", "/"), array('no_exts' => $this->allowedExtensions));
		//end scan

        $fp = fopen($this->dataOfFileAlert, "a+");
		if(!$fp){
			$fileLine = $this->FileLineCalc();
			$this->errorHandlerObject->Push(ERROR_HANDLER_ERROR, 8, "Ошибка открытия файла", $fileLine[0], $fileLine[1]);
		}
        $readData = "";
        while(!feof($fp))
            $readData .= fread($fp, 100000);
        @$readData = unserialize($readData);
		
        if(!$readData or $addAllowed)
        {	
			if($addAllowed)
				if($readData)
					$data = array_merge($readData, $addAllowed);
				else
					$data = array_merge($data, $addAllowed);
            ftruncate($fp, 0);
            fseek($fp, 0);
            fwrite($fp, serialize($data));
        }
		else
		{
			$difference = array();
			foreach($data as $val1)
			{
				$cmpFlag = false;
				foreach($readData as $val2)
					if($val1 == $val2)
					{
						$cmpFlag = true;
						break;
					}
				if(!$cmpFlag)
					$difference[] = $val1;
			}
			if($difference)
			{
				//Alert!!!
				$this->AddNotice("Возможно обнаружена угроза в файловой системе", "file_alert", $difference);
			}
		}
        fclose($fp);
		
		$this->settings->update_settings(array('last_file_alert_scan' => time()));
	}
	
	private function fileAlertScan($dir, $filters = array()){
		$files = array();
		$relRootDir = str_replace($_SERVER['DOCUMENT_ROOT'], "", $dir);
		
		$rpCache = realpath(CACHE_DIR);
		$rpImg = realpath(ROOT_DIR_IMAGES);
		$rpFiles = realpath(ROOT_DIR_FILES);
		$rpService = realpath(ROOT_DIR_SERVICE);
		
		@$dp = opendir($dir);
		if($dp){
			while(($file = readdir($dp)) !== false){
				if(($file == ".") or ($file == ".."))
					continue;
				
				$real_path = realpath($dir."/".$file);
				if(is_dir($dir."/".$file)){
						$newArr = array();
						
						if($real_path == $rpCache){
							$newArr = array("name" => ((file_exists(CACHE_DIR.'.htaccess'))?$relRootDir.'/.htaccess':''), "hash" => (file_exists(CACHE_DIR.'.htaccess'))?md5_file(CACHE_DIR.'.htaccess'):'', "size" => "1");
						}
						else if(($real_path == $rpImg) or
								($real_path == $rpFiles) or
								($real_path == $rpService)){
							$filters['exts'] = $this->forbiddenExtensions;
							$newArr = $this->fileAlertScan($real_path, $filters);
						}
						else{ 
							$newArr = $this->fileAlertScan($dir."/".$file, $filters);
						}
				  
						$files = array_merge($files, $newArr);
				}
				else
				{
					if(isset($filters['exts']) and $filters['exts']){
						$ext = pathinfo($dir."/".$file, PATHINFO_EXTENSION);
						if(!in_array($ext, $filters['exts']))
							continue;
					}
					if(isset($filters['no_exts']) and $filters['no_exts']){
						$ext = pathinfo($dir."/".$file, PATHINFO_EXTENSION);
						if(in_array($ext, $filters['no_exts']))
							continue;
					}	
					
					$size = filesize($dir."/".$file);
					$files [] = array("name" => $relRootDir."/".$file, "hash" => ($size < 10485760)?md5_file($dir."/".$file):"", "size" => $size);
				}
			}
			closedir($dp);
		}
		
		return $files;
	}
	
	//endFileAlert
	//endHandlers
   
    private $enable = false;
    private $configFile;
	private $currentConfig;
    private $alertHandlers = array('fileAlert');
    private $sendingInterval = 1800;
	
	
	//variables of alertHandlers
	private $dataOfFileAlert;
	private $fileAlertInterval = 1; 
	private $forbiddenExtensions = array("php", "js", "bin", "cgi", "csh", "hta", "jar", "plx", "pl", "pyc", "pyo");
	private $allowedExtensions = array("jpg", "png", "gif", "bmp");
}
?>