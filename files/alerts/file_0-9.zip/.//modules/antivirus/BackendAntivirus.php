<?php
/**
 * класс отображения интерфейса антивируса в административной части сайта
 * @author tim
 *
 */

class BackendAntivirus extends View {
	public function index() {
		if($this->admins->get_level_access('antivirus') != 2) return;
		
		$enabled = $this->settings->antivirus_enabled;
		$tab_active = "status";
		$may_noupdate_form = true;
		 
		if($this->request->method('get') and $this->request->get("flag", "integer"))
		{	
			$tab_active =  $this->request->post("tab_active", "string");
			
			$enabled = $this->request->get("enabled", "integer");
			$send = $this->request->get("send", "integer");
			$this->settings->update_settings(array("antivirus_enabled" => $enabled));
			
			if($enabled and $this->request->get("flag", "integer")){
				$this->antivirus->Run(true);
			}
			else if($this->request->get("flag", "integer"))
				$this->antivirus->Stop();
			
			if($send){
				$this->antivirus->SendAlerts(false, true);
			}
		}
		
		
		$this->tpl->add_var('alerts', $this->antivirus->GetAlerts(true));
		$this->tpl->add_var('enabled', $enabled);
		$this->tpl->add_var('tab_active', $tab_active);
		return $this->tpl->fetch('antivirus_status');
	}
	
	public function file_alert(){
		if($this->admins->get_level_access('antivirus') != 2) return;

		$notices = $this->antivirus->GetNotices(true);
		$tab_active = "main";
		$difference = array();
		foreach($notices as $val){
			if($val['action'] == 'file_alert')
				$difference = $val['add'];
		}

		$this->tpl->add_var('difference', $difference);
		$this->tpl->add_var('tab_active', $tab_active);
		return $this->tpl->fetch('antivirus_handler_fileAlert');
	}
	
	public function group_actions() {
		$this->admins->check_access_module('antivirus', 2);
		$items = $this->request->post("check_item", "array");
		if(is_array($items) and count($items)>0) {
			$items = array_map("intval", $items);
			switch($this->request->post("do_active", "string")) {
				case "ignore_file_alert": case "tick_files_as_alert":
				$case = $this->request->post("do_active", "string");
				$notices = $this->antivirus->GetNotices();
				$notice = $difference = array();
				foreach($notices as $val){
					if($val['action'] == 'file_alert')
					$notice = $val;
				}
					  
				$difference = $val['add'];
					
				$forbidden = array();
				$allowed = array();
				foreach($difference as $key => $val)
					if((($case == "tick_files_as_alert") and in_array($key, $items))){
						$forbidden[] = $val;
					}
					else if((($case == "ignore_file_alert") and in_array($key, $items))){
						$allowed[] = $val;
					}
					
				if($forbidden){
				
					//Alert!!!
					$path = realpath(tempnam(ROOT_DIR_FILES."/tmp/", "an_"));
					$file = "";
					$zip = new zipArchive();
					if(!$zip->open($path, ZIPARCHIVE::CREATE)){
							$this->errorsHandlerObject->Push(ERROR_HANDLER_WARNING, 1, "Не удалось открыть файл для архивации");
					}
					else {
						$count = 0;
						foreach($forbidden as $value){
							if(!file_exists($_SERVER["DOCUMENT_ROOT"]."/".$value['name']))
							continue;
							if(!$zip->addFile($_SERVER["DOCUMENT_ROOT"]."/".$value['name'], './'.$value['name'])){
								$this->errorsHandlerObject->Push(ERROR_HANDLER_WARNING, 2, "Не удалось создать архив.");
								break;
							}
							$count++;
						}
						$zip->close();
						if($count){
							$file = $path;
						}
					}
				
					$this->antivirus->AddAlert("Угроза в файловой системе", time(), $path);
					$this->antivirus->SendAlerts(false, true);
					if($path and !$this->errorHandlerObject->GetNumErrors())
						@unlink($path);
				}

				if(!$this->errorHandlerObject->GetNumErrors()){
					$this->antivirus->DeleteNotice('file_alert');
					$arr = array_merge($allowed, $forbidden);
					if(count($arr) < count($difference))
					{
						$newDifference = array();
						foreach($difference as $val1)
						{
							$cmpFlag = false;
							foreach($arr as $val2)
								if($val1 == $val2)
								{
									$cmpFlag = true;
									break;
								}
							if(!$cmpFlag)
								$newDifference[] = $val1;
						}
						$notice['add'] = $newDifference;
						$this->antivirus->AddNotice($notice['string'], $notice['action'], $notice['add']);
					}	
					$this->antivirus->fileAlert($arr);
				}
				return $this->file_alert();
				//next cases . . . 
			}
		}
		
		return $this->file_alert();
	}
}
?>