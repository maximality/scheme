<div class="bt-set right">
		<span class="btn standart-size <?php echo ($enabled) ? "red" : "blue"; ?>">
			<a href="<?php echo DIR_ADMIN; ?>?module=<?php echo $module;?>&enabled=<?php echo ($enabled)?0:1; ?>&flag=1" class="button ajax_link" data-module="<?php echo $module;?>">
				<?php if($enabled) { ?>
                <span><img class="bicon cross-w" src="<?php echo $dir_images;?>icon.png" alt="icon"/> Выключить</span>
				<?php } else { ?>
                <span><img class="bicon check-w" src="<?php echo $dir_images;?>icon.png" alt="icon"/> Включить</span>
                <?php } ?>
            </a>
		</span>
</div>
<h1><img class="security-icon" src="<?php echo $dir_images;?>icon.png" alt="icon"/> Статус защиты</h1>
<?php 
if($alerts){
			if(isset($sendInfo['code']) and ($sendInfo['code'] == 500)):
?>
			<h3 style = "color: red">В настоящий момент невозможно связаться с сервером разработчиков. Пожалуйста попробуйте позже.</h3><br/><br/>
			<?php endif; ?>
<form action="<?php echo DIR_ADMIN; ?>?module=<?php echo $module;?>" method="get" enctype="multipart/form-data">
	
				<h3>Обнаружены следующие угрозы:</h3>
   				<div class="product-table">
					<table> 
						<thead>
							<tr>
								<th>Угроза</th>
								<th>Время обнаружения</th>
							</tr>  
						</thead>
						<tbody>   
                        	<?php foreach($alerts as $alert) { ?>
							<tr>
								<td>
									<?php echo wordwrap($alert['string'], 100, '<br/>'); ?>
								</td>
								<td>
									<?php echo date("d-m-Y H:i:s", $alert['time']); ?>
								</td>
							</tr>
                            <?php } ?>
						</tbody>
						<tfoot>
							<tr>
								<th>Угроза</th>
								<th>Время обнаружения</th>
							</tr>
						</tfoot>
					</table>
					<p>Нажмите продолжить и обнаруженные данные будут отправлены разработчикам.
				</div>
				<input type = "hidden" name = "send" value = "1"/>
				<input type = "hidden" name = "flag" value = "1"/>
				<input type = "hidden" name = "enabled" value = "<?php echo $enabled; ?>"/>
	<div class="bt-set clip">
        <div class="left">
			<span class="btn standart-size blue hide-icon">
                <button class="ajax_submit" data-success-name="Сохранено">
                    <span><img class="bicon check-w" src="<?php echo $dir_images;?>icon.png" alt="icon"/> <i>Продолжить</i></span>
                </button>
			</span>
        </div>
	</div>
</form>
<?php
	}
?>
<script>
	$(function() {
		update_newcount_module("antivirus", <?php echo (intval($site->antivirus->GetNumNotices(true)) + intval($site->antivirus->GetAlerts(true))); ?>);
	});
</script>