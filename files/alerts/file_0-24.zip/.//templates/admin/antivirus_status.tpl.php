<div class="bt-set right">
		<span class="btn standart-size">
			<a href="<?php echo DIR_ADMIN; ?>?module=<?php echo $module;?>&enabled=<?php echo ($enabled)?0:1; ?>&flag=1" class="button ajax_link" data-module="<?php echo $module;?>">
				<span><?php echo (!$enabled)?"Включить":"Выключить"; ?></span>
			</a>
		</span>
</div>
<h1><img class="brands-icon" src="<?php echo $dir_images;?>icon.png" alt="icon"/>Статус защиты</h1>
<?php 
if($alerts){
?>
<form action="<?php echo DIR_ADMIN; ?>?module=<?php echo $module;?>" method="get" enctype="multipart/form-data">
	
				<h3>Обнаружены следующие угрозы:</h3>
   				<div class="product-table">
					<table> 
						<thead>
							<tr>
								<th>Угроза</th>
								<th>Время обнаружения</th>
							</tr>
						</thead>
						<tbody>
                        	<?php foreach($alerts as $alert) { ?>
							<tr>
								<td>
									<?php echo wordwrap($alert['string'], 100, '<br/>'); ?>
								</td>
								<td>
									<?php echo date("d-m-Y H:i:s", $alert['time']); ?>
								</td>
							</tr>
                            <?php } ?>
						</tbody>
						<tfoot>
							<tr>
								<th>Угроза</th>
								<th>Время обнаружения</th>
							</tr>
						</tfoot>
					</table>
					<p>Нажмите продолжить и обнаруженные данные будут отправлены разработчикам.
				</div>
				<input type = "hidden" name = "send" value = "1"/>
				<input type = "hidden" name = "flag" value = "1"/>
				<input type = "hidden" name = "enabled" value = "<?php echo $enabled; ?>"/>
	<div class="bt-set clip">
        <div class="left">
			<span class="btn standart-size blue hide-icon">
                <button class="ajax_submit" data-success-name="Сохранено">
                    <span><img class="bicon check-w" src="<?php echo $dir_images;?>icon.png" alt="icon"/> <i>Продолжить</i></span>
                </button>
			</span>
        </div>
	</div>
</form>
<?php
	}
?>